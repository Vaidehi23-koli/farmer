from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
import mysql.connector
from dotenv import load_dotenv
import os

load_dotenv()

app = Flask(__name__)
app.secret_key = "change-this-secret-key"

DB_CONFIG = {
    "host": os.getenv("DB_HOST"),
    "user": os.getenv("DB_USER"),
    "password": os.getenv("DB_PASSWORD"),
    "database": os.getenv("DB_NAME")
}

def get_db():
    return mysql.connector.connect(**DB_CONFIG)

def fetch_all(query, params=()):
    conn = get_db()
    cur = conn.cursor(dictionary=True)
    cur.execute(query, params)
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return rows

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        admin = fetch_all(
            "SELECT * FROM admins WHERE username=%s AND password=%s",
            (username, password)
        )

        if admin:
            session["admin_logged_in"] = True
            session["username"] = username
            return redirect(url_for("dashboard"))

        flash("Invalid username or password.", "danger")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

def execute(query, params=()):
    conn = get_db()
    cur = conn.cursor()
    cur.execute(query, params)
    conn.commit()
    last_id = cur.lastrowid
    cur.close()
    conn.close()
    return last_id

@app.route("/")
def dashboard():
    if not session.get("admin_logged_in"):
        return redirect(url_for("login"))
    stats = {
        "farmers": fetch_all("SELECT COUNT(*) c FROM farmers")[0]["c"],
        "active_surveys": fetch_all("SELECT COUNT(*) c FROM surveys WHERE status='Active'")[0]["c"],
        "responses": fetch_all("SELECT COUNT(*) c FROM survey_responses")[0]["c"],
        "avg_satisfaction": round(fetch_all(
            "SELECT COALESCE(AVG(satisfaction),0) v FROM survey_responses"
        )[0]["v"], 1)
    }
    recent = fetch_all("""
        SELECT r.id, f.name farmer, s.title survey, r.satisfaction, r.submitted_at
        FROM survey_responses r
        JOIN farmers f ON f.id=r.farmer_id
        JOIN surveys s ON s.id=r.survey_id
        ORDER BY r.submitted_at DESC LIMIT 6
    """)
    return render_template("dashboard.html", stats=stats, recent=recent)

# Farmer Management
@app.route("/farmers")
def farmers():

    if not session.get("admin_logged_in"):
        return redirect(url_for("login"))

    q = request.args.get("q", "").strip()

    farmers_list = fetch_all("""
        SELECT *
        FROM farmers
        WHERE name LIKE %s
           OR farmer_code LIKE %s
           OR village LIKE %s
           OR district LIKE %s
        ORDER BY id DESC
    """, (
        f"%{q}%",
        f"%{q}%",
        f"%{q}%",
        f"%{q}%"
    ))

    # Farmer statistics
    total_farmers = fetch_all(
        "SELECT COUNT(*) AS count FROM farmers"
    )[0]["count"]

    active_farmers = fetch_all(
        "SELECT COUNT(*) AS count FROM farmers WHERE status='Active'"
    )[0]["count"]

    inactive_farmers = fetch_all(
        "SELECT COUNT(*) AS count FROM farmers WHERE status='Inactive'"
    )[0]["count"]

    crop_count = fetch_all("""
        SELECT COUNT(DISTINCT crop) AS count
        FROM farmers
        WHERE crop IS NOT NULL AND crop != ''
    """)[0]["count"]

    return render_template(
        "farmers.html",
        farmers=farmers_list,
        q=q,
        total_farmers=total_farmers,
        active_farmers=active_farmers,
        inactive_farmers=inactive_farmers,
        crop_count=crop_count
    )

# ----------------------------------------------------------
# ADD FARMER
@app.route("/farmers/add", methods=["POST"])
def add_farmer():

    if not session.get("admin_logged_in"):
        return redirect(url_for("login"))

    execute("""
        INSERT INTO farmers
        (
            farmer_code,
            name,
            phone,
            email,
            village,
            district,
            crop,
            age,
            gender,
            land_size,
            irrigation,
            experience,
            status
        )
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """, (
        request.form["farmer_code"],
        request.form["name"],
        request.form.get("phone"),
        request.form.get("email"),
        request.form.get("village"),
        request.form.get("district"),
        request.form.get("crop"),
        request.form.get("age") or None,
        request.form.get("gender") or None,
        request.form.get("land_size") or None,
        request.form.get("irrigation"),
        request.form.get("experience") or None,
        request.form.get("status", "Active")
    ))

    flash("Farmer added successfully.", "success")

    return redirect(url_for("farmers"))

# ----------------------------------------------------------
# VIEW FARMER PROFILE
@app.route("/farmers/<int:farmer_id>")
def farmer_profile(farmer_id):

    if not session.get("admin_logged_in"):
        return redirect(url_for("login"))

    farmer = fetch_all("""
        SELECT *
        FROM farmers
        WHERE id=%s
    """, (farmer_id,))

    if not farmer:
        flash("Farmer not found.", "danger")
        return redirect(url_for("farmers"))

    farmer = farmer[0]

    # Get this farmer's survey history
    responses = fetch_all("""
        SELECT
            r.id,
            s.title AS survey,
            r.satisfaction,
            r.service_quality,
            r.recommendation,
            r.comments,
            r.submitted_at
        FROM survey_responses r
        JOIN surveys s ON s.id = r.survey_id
        WHERE r.farmer_id=%s
        ORDER BY r.submitted_at DESC
    """, (farmer_id,))

    return render_template(
        "farmer_profile.html",
        farmer=farmer,
        responses=responses
    )

# ----------------------------------------------------------
# EDIT FARMER
@app.route("/farmers/edit/<int:farmer_id>", methods=["GET", "POST"])
def edit_farmer(farmer_id):

    if not session.get("admin_logged_in"):
        return redirect(url_for("login"))

    if request.method == "POST":

        execute("""
            UPDATE farmers
            SET
                farmer_code=%s,
                name=%s,
                phone=%s,
                email=%s,
                village=%s,
                district=%s,
                crop=%s,
                age=%s,
                gender=%s,
                land_size=%s,
                irrigation=%s,
                experience=%s,
                status=%s
            WHERE id=%s
        """, (
            request.form["farmer_code"],
            request.form["name"],
            request.form.get("phone"),
            request.form.get("email"),
            request.form.get("village"),
            request.form.get("district"),
            request.form.get("crop"),
            request.form.get("age") or None,
            request.form.get("gender") or None,
            request.form.get("land_size") or None,
            request.form.get("irrigation"),
            request.form.get("experience") or None,
            request.form.get("status", "Active"),
            farmer_id
        ))

        flash("Farmer updated successfully.", "success")

        return redirect(url_for(
            "farmer_profile",
            farmer_id=farmer_id
        ))

    farmer = fetch_all("""
        SELECT *
        FROM farmers
        WHERE id=%s
    """, (farmer_id,))

    if not farmer:
        flash("Farmer not found.", "danger")
        return redirect(url_for("farmers"))

    return render_template(
        "edit_farmer.html",
        farmer=farmer[0]
    )

# ----------------------------------------------------------
# DELETE FARMER
@app.route("/farmers/delete/<int:farmer_id>", methods=["POST"])
def delete_farmer(farmer_id):

    if not session.get("admin_logged_in"):
        return redirect(url_for("login"))

    execute(
        "DELETE FROM farmers WHERE id=%s",
        (farmer_id,)
    )

    flash("Farmer removed successfully.", "success")

    return redirect(url_for("farmers"))

# Survey & Feedback Management
@app.route("/surveys")
def surveys():
    rows = fetch_all("""
        SELECT s.*, COUNT(r.id) responses
        FROM surveys s LEFT JOIN survey_responses r ON r.survey_id=s.id
        GROUP BY s.id ORDER BY s.id DESC
    """)
    return render_template("surveys.html", surveys=rows)

@app.route("/surveys/add", methods=["POST"])
def add_survey():
    execute("""
        INSERT INTO surveys(title,description,survey_date,status)
        VALUES(%s,%s,%s,%s)
    """, (
        request.form["title"], request.form.get("description"),
        request.form["survey_date"], request.form.get("status","Draft")
    ))
    flash("Survey created.", "success")
    return redirect(url_for("surveys"))

@app.route("/survey-responses/<int:survey_id>")
def survey_responses(survey_id):
    if not session.get("admin_logged_in"):
        return redirect(url_for("login"))

    responses = fetch_all("""
        SELECT *
        FROM survey_responses
        WHERE survey_id = %s
        ORDER BY id DESC
    """, (survey_id,))

    survey = fetch_all(
        "SELECT * FROM surveys WHERE id = %s",
        (survey_id,)
    )

    if not survey:
        flash("Survey not found.", "danger")
        return redirect(url_for("surveys"))

    return render_template(
        "survey_responses.html",
        responses=responses,
        survey=survey[0]
    )

@app.route("/feedback")
def feedback():
    responses = fetch_all("""
        SELECT r.*, s.title AS survey
        FROM survey_responses r
        JOIN surveys s ON s.id = r.survey_id
        ORDER BY r.id DESC
    """)

    surveys_list = fetch_all(
        "SELECT id, title FROM surveys WHERE status='Active' ORDER BY id DESC"
    )

    return render_template(
        "feedback.html",
        responses=responses,
        surveys=surveys_list
    )

@app.route("/feedback/add", methods=["POST"])
def add_feedback():
    if not session.get("admin_logged_in"):
        return redirect(url_for("login"))

    try:
        # Get the state and district
        state = request.form.get("state")
        district = request.form.get("district")

        # Get all 15 survey answers
        q1 = request.form.get("q1")
        q2 = request.form.get("q2")
        q3 = request.form.get("q3")
        q4 = request.form.get("q4")
        q5 = request.form.get("q5")
        q6 = request.form.get("q6")
        q7 = request.form.get("q7")
        q8 = request.form.get("q8")
        q9 = request.form.get("q9")
        q10 = request.form.get("q10")
        q11 = request.form.get("q11")
        q12 = request.form.get("q12")
        q13 = request.form.get("q13")
        q14 = request.form.get("q14")
        q15 = request.form.get("q15")

        # Get comments
        comments = request.form.get("comments", "").strip()

        # Use the currently active survey
        active_survey = fetch_all("""
            SELECT id
            FROM surveys
            WHERE status='Active'
            ORDER BY id DESC
            LIMIT 1
        """)

        if not active_survey:
            flash("No active survey is available.", "danger")
            return redirect(url_for("feedback"))

        survey_id = active_survey[0]["id"]

        # Save the survey response
        execute("""
            INSERT INTO survey_responses
            (
                survey_id,
                farmer_id,
                state,
                district,
                satisfaction,
                service_quality,
                recommendation,
                q1, q2, q3, q4, q5,
                q6, q7, q8, q9, q10,
                q11, q12, q13, q14, q15,
                comments
            )
            VALUES (
                %s, NULL, %s, %s,
                %s, %s, %s,
                %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s,
                %s
            )
        """, (
            survey_id,
            state,
            district,

            # Keep the old rating columns populated
            q15,
            q15,
            q15,

            q1, q2, q3, q4, q5,
            q6, q7, q8, q9, q10,
            q11, q12, q13, q14, q15,

            comments
        ))

        flash("Survey submitted successfully!", "success")
        return redirect(url_for("feedback"))

    except Exception as e:
        print("Survey submission error:", e)
        flash("There was a problem submitting the survey.", "danger")
        return redirect(url_for("feedback"))

# Data Analysis & Visualization
@app.route("/analytics")
def analytics():
    survey_id = request.args.get("survey_id")
    state = request.args.get("state")
    district_filter = request.args.get("district")
    crop_filter = request.args.get("crop")

    summary = fetch_all("""
        SELECT
            COUNT(*) AS responses,
            ROUND(AVG(r.satisfaction), 2) AS avg_satisfaction,
            ROUND(AVG(r.service_quality), 2) AS avg_quality,
            ROUND(AVG(r.recommendation), 2) AS avg_recommendation
        FROM survey_responses r
        LEFT JOIN farmers f ON f.id = r.farmer_id
        WHERE (%s IS NULL OR r.survey_id = %s)
        AND (%s IS NULL OR r.state = %s)
        AND (%s IS NULL OR r.district = %s)
        AND (%s IS NULL OR f.crop = %s)
    """, (survey_id, survey_id, state, state, district_filter, district_filter, crop_filter, crop_filter))[0]

    distribution = fetch_all("""
        SELECT
            r.satisfaction AS rating,
            COUNT(*) AS count
        FROM survey_responses r
        LEFT JOIN farmers f ON f.id = r.farmer_id
        WHERE (%s IS NULL OR r.survey_id = %s)
            AND (%s IS NULL OR r.state = %s)
            AND (%s IS NULL OR r.district = %s)
            AND (%s IS NULL OR f.crop = %s)
        GROUP BY r.satisfaction
        ORDER BY r.satisfaction
    """, (survey_id, survey_id, state, state, district_filter, district_filter, crop_filter, crop_filter))

    crop = fetch_all("""
        SELECT
            COALESCE(f.crop, 'Not specified') AS crop,
            ROUND(AVG(r.satisfaction), 2) AS score,
            COUNT(*) AS responses
        FROM survey_responses r
        LEFT JOIN farmers f ON f.id = r.farmer_id
        WHERE (%s IS NULL OR r.survey_id = %s)
            AND (%s IS NULL OR r.state = %s)
            AND (%s IS NULL OR r.district = %s)
            AND (%s IS NULL OR f.crop = %s)
        GROUP BY COALESCE(f.crop, 'Not specified')
        ORDER BY score DESC
    """, (survey_id, survey_id, state, state, district_filter, district_filter, crop_filter, crop_filter))

    district = fetch_all("""
        SELECT
            COALESCE(r.district, 'Not specified') AS district,
            ROUND(AVG(r.satisfaction), 2) AS score,
            COUNT(*) AS responses
        FROM survey_responses r
        LEFT JOIN farmers f ON f.id = r.farmer_id
        WHERE (%s IS NULL OR r.survey_id = %s)
            AND (%s IS NULL OR r.state = %s)
            AND (%s IS NULL OR r.district = %s)
            AND (%s IS NULL OR f.crop = %s)
        GROUP BY COALESCE(r.district, 'Not specified')
        ORDER BY score DESC
    """, (survey_id, survey_id, state, state, district_filter, district_filter, crop_filter, crop_filter))

    question_scores = fetch_all("""
        SELECT
            ROUND(AVG(q1), 2) AS q1,
            ROUND(AVG(q2), 2) AS q2,
            ROUND(AVG(q3), 2) AS q3,
            ROUND(AVG(q4), 2) AS q4,
            ROUND(AVG(q5), 2) AS q5,
            ROUND(AVG(q6), 2) AS q6,
            ROUND(AVG(q7), 2) AS q7,
            ROUND(AVG(q8), 2) AS q8,
            ROUND(AVG(q9), 2) AS q9,
            ROUND(AVG(q10), 2) AS q10,
            ROUND(AVG(q11), 2) AS q11,
            ROUND(AVG(q12), 2) AS q12,
            ROUND(AVG(q13), 2) AS q13,
            ROUND(AVG(q14), 2) AS q14,
            ROUND(AVG(q15), 2) AS q15
        FROM survey_responses r
        LEFT JOIN farmers f ON f.id = r.farmer_id
        WHERE (%s IS NULL OR r.survey_id = %s)
            AND (%s IS NULL OR r.state = %s)
            AND (%s IS NULL OR r.district = %s)
            AND (%s IS NULL OR f.crop = %s)
        """, (survey_id, survey_id, state, state, district_filter, district_filter, crop_filter, crop_filter))[0]

    return render_template(
        "analytics.html",
        summary=summary,
        distribution=distribution,
        crop=crop,
        district=district,
        question_scores=question_scores,
        surveys=fetch_all("SELECT id, title FROM surveys ORDER BY id DESC"),
        states=fetch_all("""
            SELECT DISTINCT state
            FROM survey_responses
            WHERE state IS NOT NULL AND state != ''
            ORDER BY state
        """),
        districts=fetch_all("""
            SELECT DISTINCT district
            FROM survey_responses
            WHERE district IS NOT NULL AND district != ''
            ORDER BY district
        """),
        crops=fetch_all("""
            SELECT DISTINCT crop
            FROM farmers
            WHERE crop IS NOT NULL AND crop != ''
            ORDER BY crop
        """)
    )

# Admin & Report Management
@app.route("/admin")
def admin():
    q = request.args.get("q", "")
    status = request.args.get("status", "")
    date_from = request.args.get("date_from", "")
    date_to = request.args.get("date_to", "")
    district = request.args.get("district", "")

    query = """
        SELECT s.id, s.title, s.status,
               s.survey_date,
               COUNT(r.id) responses,
               ROUND(COALESCE(AVG(r.satisfaction),0),2) satisfaction
        FROM surveys s
        LEFT JOIN survey_responses r ON r.survey_id=s.id
        WHERE 1=1
    """

    params = []

    if q:
        query += " AND s.title LIKE %s"
        params.append(f"%{q}%")

    if status:
        query += " AND s.status=%s"
        params.append(status)

    if date_from:
        query += " AND s.survey_date >= %s"
        params.append(date_from)

    if date_to:
        query += " AND s.survey_date <= %s"
        params.append(date_to)

    if district:
        query += """
            AND EXISTS (
                SELECT 1
                FROM survey_responses sr
                WHERE sr.survey_id = s.id
                AND sr.district = %s
            )
        """
        params.append(district)

    query += """
        GROUP BY s.id
        ORDER BY s.id DESC
    """
    reports = fetch_all(query, tuple(params))

    # Summary numbers
    total_surveys = fetch_all(
        "SELECT COUNT(*) c FROM surveys"
    )[0]["c"]

    total_responses = fetch_all(
        "SELECT COUNT(*) c FROM survey_responses"
    )[0]["c"]

    active_surveys = fetch_all(
        "SELECT COUNT(*) c FROM surveys WHERE status='Active'"
    )[0]["c"]

    avg_satisfaction = fetch_all(
        "SELECT ROUND(COALESCE(AVG(satisfaction),0),1) v FROM survey_responses"
    )[0]["v"]

    return render_template(
        "admin.html",
        reports=reports,
        q=q,
        status=status,
        date_from=date_from,
        date_to=date_to,
        district=district,
        total_surveys=total_surveys,
        total_responses=total_responses,
        active_surveys=active_surveys,
        avg_satisfaction=avg_satisfaction
    )

@app.route("/admin/report/<int:survey_id>")
def report_detail(survey_id):

    survey = fetch_all("""
        SELECT id, title, description, survey_date, status
        FROM surveys
        WHERE id=%s
    """, (survey_id,))

    if not survey:
        return "Report not found", 404

    survey = survey[0]

    summary = fetch_all("""
        SELECT
            COUNT(*) AS responses,
            ROUND(COALESCE(AVG(satisfaction), 0), 2) AS avg_satisfaction,
            ROUND(COALESCE(AVG(service_quality), 0), 2) AS avg_quality,
            ROUND(COALESCE(AVG(recommendation), 0), 2) AS avg_recommendation
        FROM survey_responses
        WHERE survey_id=%s
    """, (survey_id,))[0]

    responses = fetch_all("""
        SELECT
            r.id,
            r.satisfaction,
            r.service_quality,
            r.recommendation,
            r.comments,
            r.submitted_at,
            COALESCE(f.name, 'Anonymous') AS farmer_name,
            COALESCE(r.district, 'Not specified') AS district,
            COALESCE(r.state, 'Not specified') AS state
        FROM survey_responses r
        LEFT JOIN farmers f ON f.id = r.farmer_id
        WHERE r.survey_id=%s
        ORDER BY r.id DESC
    """, (survey_id,))

    return render_template(
        "report_detail.html",
        survey=survey,
        summary=summary,
        responses=responses
    )

#EXPORT REPORT AS CSV
@app.route("/admin/report/<int:survey_id>/export")
def export_report_csv(survey_id):

    survey = fetch_all("""
        SELECT id, title
        FROM surveys
        WHERE id=%s
    """, (survey_id,))

    if not survey:
        return "Report not found", 404

    survey = survey[0]

    responses = fetch_all("""
        SELECT
            COALESCE(f.name, 'Anonymous') AS farmer_name,
            COALESCE(r.state, 'Not specified') AS state,
            COALESCE(r.district, 'Not specified') AS district,
            r.satisfaction,
            r.service_quality,
            r.recommendation,
            COALESCE(r.comments, '') AS comments,
            r.submitted_at
        FROM survey_responses r
        LEFT JOIN farmers f ON f.id = r.farmer_id
        WHERE r.survey_id=%s
        ORDER BY r.id DESC
    """, (survey_id,))

    import csv
    from io import StringIO

    output = StringIO()

    writer = csv.writer(output)

    writer.writerow([
        "Farmer",
        "State",
        "District",
        "Satisfaction",
        "Service Quality",
        "Recommendation",
        "Comments",
        "Submitted At"
    ])

    for r in responses:
        writer.writerow([
            r["farmer_name"],
            r["state"],
            r["district"],
            r["satisfaction"],
            r["service_quality"],
            r["recommendation"],
            r["comments"],
            r["submitted_at"]
        ])

    filename = f"survey_report_{survey_id}.csv"

    from flask import Response

    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={
            "Content-Disposition": f"attachment; filename={filename}"
        }
    )

# LOW-SATISFACTION REPORT
@app.route("/admin/low-satisfaction")
def low_satisfaction_report():

    responses = fetch_all("""
        SELECT
            r.id,
            COALESCE(f.name, 'Anonymous') AS farmer_name,
            COALESCE(r.state, 'Not specified') AS state,
            COALESCE(r.district, 'Not specified') AS district,
            s.title AS survey,
            r.satisfaction,
            r.service_quality,
            r.recommendation,
            r.comments,
            r.submitted_at
        FROM survey_responses r
        LEFT JOIN farmers f ON f.id = r.farmer_id
        JOIN surveys s ON s.id = r.survey_id
        WHERE r.satisfaction <= 2
        ORDER BY r.satisfaction ASC, r.id DESC
    """)

    return render_template(
        "low_satisfaction.html",
        responses=responses
    )

@app.route("/api/analytics")
def analytics_api():
    monthly = fetch_all("""
        SELECT DATE_FORMAT(submitted_at,'%b') month,
               ROUND(AVG(satisfaction),2) satisfaction
        FROM survey_responses
        GROUP BY YEAR(submitted_at), MONTH(submitted_at)
        ORDER BY YEAR(submitted_at), MONTH(submitted_at)
    """)
    return jsonify(monthly)

# Settings
@app.route("/settings", methods=["GET", "POST"])
def settings():
    if not session.get("admin_logged_in"):
        return redirect(url_for("login"))

    username = session.get("username", "admin")

    if request.method == "POST":

        form_type = request.form.get("form_type")


        # NOTIFICATION SETTINGS
        if form_type == "notifications":

            notifications_enabled = 1 if request.form.get(
                "notifications_enabled"
            ) else 0

            execute("""
                UPDATE admins
                SET notifications_enabled=%s
                WHERE username=%s
            """, (
                notifications_enabled,
                username
            ))

            flash("Notification settings updated successfully.", "success")
            return redirect(url_for("settings"))


        # PROFILE SETTINGS
        new_username = request.form.get("username", "").strip()

        if not new_username:
            flash("Username cannot be empty.", "danger")
            return redirect(url_for("settings"))

        try:

            execute("""
                UPDATE admins
                SET username=%s
                WHERE username=%s
            """, (
                new_username,
                username
            ))

            session["username"] = new_username

            flash("Profile updated successfully.", "success")
            return redirect(url_for("settings"))
    
        except Exception:
            flash("That username may already be in use.", "danger")
            return redirect(url_for("settings"))

    admin = fetch_all(
        """
        SELECT
            username,
            role,
            notifications_enabled
        FROM admins
        WHERE username=%s
        """,
        (username,)
    )

    if not admin:
        flash("Admin account not found.", "danger")
        return redirect(url_for("dashboard"))

    response_count = fetch_all(
        "SELECT COUNT(*) AS count FROM survey_responses"
    )[0]["count"]

    return render_template(
        "settings.html",
        admin=admin[0],
        response_count=response_count
    )
    

# CHANGE PASSWORD
@app.route("/change-password", methods=["POST"])
def change_password():

    if not session.get("admin_logged_in"):
        return redirect(url_for("login"))

    username = session.get("username", "admin")

    current_password = request.form.get("current_password")
    new_password = request.form.get("new_password")
    confirm_password = request.form.get("confirm_password")

    # Check that new passwords match
    if new_password != confirm_password:
        flash("New passwords do not match.", "danger")
        return redirect(url_for("settings"))

    # Check current password
    admin = fetch_all(
        """
        SELECT * FROM admins
        WHERE username=%s AND password=%s
        """,
        (username, current_password)
    )

    if not admin:
        flash("Current password is incorrect.", "danger")
        return redirect(url_for("settings"))

    # Update password
    execute(
        """
        UPDATE admins
        SET password=%s
        WHERE username=%s
        """,
        (new_password, username)
    )

    flash("Password changed successfully.", "success")
    return redirect(url_for("settings"))

# health
@app.route("/health")
def health():
    try:
        conn = get_db()
        conn.close()
        return {"status":"ok","database":"connected"}
    except Exception as e:
        return {"status":"error","database":str(e)}, 500

if __name__ == "__main__":
    app.run(debug=True)
