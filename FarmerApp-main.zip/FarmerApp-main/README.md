# FarmPulse — Farmer Feedback & Satisfaction Analysis using survey
A web-based management system for collecting farmer feedback through surveys and analyzing farmer satisfaction.

## Features
- Farmer Management
- Survey & Feedback Management
- Data Analysis & Visualization
- Admin & Report Management
- Admin Login
- Account Settings

## Stack
HTML5, CSS3, Bootstrap 5, JavaScript/Chart.js, Python Flask, MySQL.

## Modules
1. Farmer Management
2. Survey & Feedback Management
3. Data Analysis & Visualization
4. Admin & Report Management

## How to run
1. Install Python
   Make sure Python is installed on your computer.

2. Install SQL workbench. Paste the enire Schema sql code in the workbench and run. (This is to create database.) 

3. Create a virtual environment in new terminal by using command:
    `python -m venv venv`
   
4. Run:
   Restarrt the flask first using "CRTL+C" 
   then write command:
   `python app.py`
   
7. Open `http://127.0.0.1:5000`

If PowerShell blocks activation, simply use:
`python -m pip install -r requirements.txt`
and then:
`python app.py`

## Demo login data
Database seed includes `Admin / Farmer123` as placeholder credentials.
Authentication is intentionally not implemented in this starter. Add Flask-Login/password hashing before production use.
