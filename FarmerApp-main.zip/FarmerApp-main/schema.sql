-- ============================================
-- FARMPULSE
-- Farmer Feedback & Satisfaction Analysis
-- FINAL DATABASE SCHEMA
-- ============================================


-- ============================================
-- DATABASE
-- ============================================

CREATE DATABASE IF NOT EXISTS farmer_feedback;

USE farmer_feedback;


-- ============================================
-- 1. FARMERS TABLE
-- ============================================

CREATE TABLE IF NOT EXISTS farmers (

    id INT AUTO_INCREMENT PRIMARY KEY,

    farmer_code VARCHAR(30) UNIQUE NOT NULL,

    name VARCHAR(120) NOT NULL,

    age INT,

    gender VARCHAR(20),

    phone VARCHAR(30),

    email VARCHAR(120),

    village VARCHAR(120),

    district VARCHAR(120),

    crop VARCHAR(120),

    land_size DECIMAL(10,2),

    irrigation VARCHAR(100),

    experience INT,

    status ENUM('Active','Inactive') DEFAULT 'Active',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

);


-- ============================================
-- 2. SURVEYS TABLE
-- ============================================

CREATE TABLE IF NOT EXISTS surveys (

    id INT AUTO_INCREMENT PRIMARY KEY,

    title VARCHAR(200) NOT NULL,

    description TEXT,

    survey_date DATE NOT NULL,

    status ENUM('Draft','Active','Closed') DEFAULT 'Draft',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

);


-- ============================================
-- 3. SURVEY RESPONSES TABLE
-- ============================================

CREATE TABLE IF NOT EXISTS survey_responses (

    id INT AUTO_INCREMENT PRIMARY KEY,

    survey_id INT NOT NULL,

    -- NULL allows anonymous feedback
    farmer_id INT NULL,

    state VARCHAR(120),

    district VARCHAR(120),

    -- Overall satisfaction
    satisfaction INT NOT NULL,

    -- Service quality
    service_quality INT NOT NULL,

    -- Recommendation
    recommendation INT NOT NULL,

    -- Survey questions
    q1 INT NOT NULL,
    q2 INT NOT NULL,
    q3 INT NOT NULL,
    q4 INT NOT NULL,
    q5 INT NOT NULL,
    q6 INT NOT NULL,
    q7 INT NOT NULL,
    q8 INT NOT NULL,
    q9 INT NOT NULL,
    q10 INT NOT NULL,
    q11 INT NOT NULL,
    q12 INT NOT NULL,
    q13 INT NOT NULL,
    q14 INT NOT NULL,
    q15 INT NOT NULL,

    comments TEXT,

    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (survey_id)
        REFERENCES surveys(id)
        ON DELETE CASCADE,

    FOREIGN KEY (farmer_id)
        REFERENCES farmers(id)
        ON DELETE CASCADE

);


-- ============================================
-- 4. ADMINS TABLE
-- ============================================

CREATE TABLE IF NOT EXISTS admins (

    id INT AUTO_INCREMENT PRIMARY KEY,

    username VARCHAR(80) UNIQUE NOT NULL,

    password VARCHAR(255) NOT NULL,

    role VARCHAR(50) DEFAULT 'Administrator',

    -- Notification / alert setting
    notifications_enabled TINYINT(1) DEFAULT 1

);


-- ============================================
-- 5. SAMPLE ADMIN ACCOUNT
-- ============================================

INSERT IGNORE INTO admins
(username, password, role, notifications_enabled)

VALUES
('Admin', 'Farmer123', 'Administrator', 1);


-- ============================================
-- 6. SAMPLE FARMERS
-- ============================================

INSERT IGNORE INTO farmers
(
    farmer_code,
    name,
    age,
    gender,
    phone,
    email,
    village,
    district,
    crop,
    land_size,
    irrigation,
    experience,
    status
)

VALUES

(
    'F001',
    'Arun Kumar',
    42,
    'Male',
    '9876543210',
    'arun@example.com',
    'Greenfield',
    'Mysuru',
    'Tomato',
    4.50,
    'Borewell',
    15,
    'Active'
),

(
    'F002',
    'Meena Devi',
    38,
    'Female',
    '9876501234',
    'meena@example.com',
    'Riverbank',
    'Mandya',
    'Rice',
    3.20,
    'Canal',
    12,
    'Active'
),

(
    'F003',
    'Ravi Singh',
    45,
    'Male',
    '9123456780',
    'ravi@example.com',
    'Sunrise',
    'Hassan',
    'Maize',
    5.00,
    'Borewell',
    18,
    'Active'
);


-- ============================================
-- 7. SAMPLE SURVEY
-- ============================================

INSERT IGNORE INTO surveys
(
    id,
    title,
    description,
    survey_date,
    status
)

VALUES
(
    1,
    'Monthly Farmer Satisfaction Survey',
    'Measure farmer satisfaction with support and services.',
    CURDATE(),
    'Active'
);


-- ============================================
-- 8. SAMPLE SURVEY RESPONSES
-- ============================================

-- Response 1
INSERT IGNORE INTO survey_responses
(
    survey_id,
    farmer_id,
    state,
    district,
    satisfaction,
    service_quality,
    recommendation,
    q1, q2, q3, q4, q5,
    q6, q7, q8, q9, q10,
    q11, q12, q13, q14, q15,
    comments
)

VALUES
(
    1,
    1,
    'Karnataka',
    'Mysuru',
    5,
    4,
    5,
    5, 5, 4, 5, 5,
    4, 5, 5, 4, 5,
    5, 4, 5, 5, 5,
    'Very helpful support.'
);


-- Response 2
INSERT IGNORE INTO survey_responses
(
    survey_id,
    farmer_id,
    state,
    district,
    satisfaction,
    service_quality,
    recommendation,
    q1, q2, q3, q4, q5,
    q6, q7, q8, q9, q10,
    q11, q12, q13, q14, q15,
    comments
)

VALUES
(
    1,
    2,
    'Karnataka',
    'Mandya',
    4,
    4,
    4,
    4, 4, 5, 4, 4,
    4, 5, 4, 4, 4,
    4, 4, 5, 4, 4,
    'Good service, but response time can improve.'
);


-- Response 3
INSERT IGNORE INTO survey_responses
(
    survey_id,
    farmer_id,
    state,
    district,
    satisfaction,
    service_quality,
    recommendation,
    q1, q2, q3, q4, q5,
    q6, q7, q8, q9, q10,
    q11, q12, q13, q14, q15,
    comments
)

VALUES
(
    1,
    3,
    'Karnataka',
    'Hassan',
    3,
    3,
    3,
    3, 3, 3, 4, 3,
    3, 3, 4, 3, 3,
    3, 4, 3, 3, 3,
    'Average experience.'
);


-- ============================================
-- 9. SAMPLE ANONYMOUS RESPONSE
-- ============================================

INSERT IGNORE INTO survey_responses
(
    survey_id,
    farmer_id,
    state,
    district,
    satisfaction,
    service_quality,
    recommendation,
    q1, q2, q3, q4, q5,
    q6, q7, q8, q9, q10,
    q11, q12, q13, q14, q15,
    comments
)

VALUES
(
    1,
    NULL,
    'Maharashtra',
    'Pune',
    5,
    5,
    5,
    5, 5, 5, 5, 5,
    5, 5, 5, 5, 5,
    5, 5, 5, 5, 5,
    'Anonymous feedback.'
);


-- ============================================
-- DATABASE SETUP COMPLETE
-- ============================================