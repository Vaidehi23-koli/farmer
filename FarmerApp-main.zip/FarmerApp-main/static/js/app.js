document.querySelectorAll('form').forEach(form=>{
  form.addEventListener('submit',()=>{
    const btn=form.querySelector('button[type="submit"],button:not([type])');
    if(btn && !form.closest('.modal')) btn.disabled=true;
  });
});
